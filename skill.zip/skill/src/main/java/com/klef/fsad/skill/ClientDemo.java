package com.klef.fsad.skill;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class ClientDemo 
{
    public static void main(String[] args) 
    {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");

        SessionFactory sf = cfg.buildSessionFactory();
        Session session = sf.openSession();

        Transaction tx = session.beginTransaction();

        // Insert Record
        Service s = new Service();
        s.setId(1);
        s.setName("Repair");
        s.setDate("2026-03-12");
        s.setStatus("Pending");

        session.save(s);

        // HQL Update
        String hql = "update Service set name=:name, status=:status where id=:id";

        Query<?> q = session.createQuery(hql);
        q.setParameter("name", "Maintenance");
        q.setParameter("status", "Completed");
        q.setParameter("id", 1);

        int n = q.executeUpdate();

        System.out.println("Updated Records = " + n);

        tx.commit();

        session.close();
        sf.close();
    }
}w